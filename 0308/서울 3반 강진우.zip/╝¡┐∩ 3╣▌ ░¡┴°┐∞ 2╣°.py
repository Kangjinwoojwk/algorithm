dx = [-1, 1, 0, 0]
dy = [0, 0, 1, -1]


def island(x, y):  # 들렀던 섬이라고 표시해주는 함수
    global N
    chk[x][y] = False  # 들렀던 곳이라고 표시
    for i in range(4):
        nx, ny = x + dx[i], y + dy[i]  # 상하좌우
        if 0 <= nx < N and 0 <= ny < N:  # 배열 초과는 아닌지 확인
            if chk[nx][ny] and data[nx][ny] != 0:  # 들른적 없는데 섬이다! 그러면 붙어 있는 섬이다!
                island(nx, ny)  # 들어가서 바꿔주자!


T = int(input())
for tc in range(1, T + 1):
    N = int(input())
    data = [list(map(int, input().split())) for _ in range(N)]
    chk = [[True] * N for _ in range(N)]
    max_height = 0
    cnt = 0
    for i in range(N):
        for j in range(N):
            if chk[i][j] and data[i][j] != 0:  # 접근 한적 없는데 섬이라면
                cnt += 1 # 섬 개수 추가
                island(i, j) # 하나의 섬 을 전부 센다.
            if data[i][j] > max_height:
                max_height = data[i][j]  # 전부 돌면서 가장 큰값을 찾는다.
    print('#{} {} {}'.format(tc, cnt, max_height))
