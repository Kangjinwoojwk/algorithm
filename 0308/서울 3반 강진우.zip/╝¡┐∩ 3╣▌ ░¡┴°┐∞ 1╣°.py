def sol():
    global ans, N, K  # 매개변수로 받을 까 하다가 대문자는 어차피 안변하는 거로 ans는 바뀌어야 하니 global
    for i in range(N - K + 1):  # 규칙대로 하면 N - K 제곱의 가능성이 있다.
        for j in range(N - K + 1):
            a = 0  # 우하향 대각선 초기화
            b = 0  # 우상향 대각선 초기화
            for k in range(K):
                a += data[i + k][j + k]  # 우하향 합
                b += data[i + K - 1 - k][j + k]  # 우상향 합
            c = abs(a - b)  # 큰거고르느니 절댓값 처리
            if c < ans:  # ans보다 작으면 바꿔준다.
                ans = c


T = int(input())
for tc in range(1, T + 1):
    N, K = map(int, input().split())
    data = [list(map(int, input().split())) for _ in range(N)]  # data를 전부 받는다.
    ans = 1 << 30  # 최소값을 찾으라니 일단 엄청 크게 50까지 전부 100으로 들어 와도 큰 숫자 사용
    sol()
    print('#{} {}'.format(tc, ans))